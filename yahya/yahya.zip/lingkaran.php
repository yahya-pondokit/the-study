<!DOCTYPE html>
<html>
<head>
	<title>Luas Lingkaran</title>
</head>
<body>
	<?php
		function lingkaran ($j, $phi=22/7){
			echo $j * $j * $phi;
		}
		lingkaran (28);
	?>
</body>
			