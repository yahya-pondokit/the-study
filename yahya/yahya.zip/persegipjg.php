<!DOCTYPE html>
<html>
<head>
	<title>Rumus Persegi Pjg</title>
</head>
<body>
	<?php
		function persegi ($a, $t){
			echo $a * $t;
		}
		persegi(667,3);
	?>
</body>